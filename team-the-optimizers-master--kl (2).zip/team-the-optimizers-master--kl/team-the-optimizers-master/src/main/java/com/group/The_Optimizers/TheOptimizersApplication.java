package com.group.The_Optimizers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TheOptimizersApplication {

	public static void main(String[] args) {
		SpringApplication.run(TheOptimizersApplication.class, args);
	}

}
